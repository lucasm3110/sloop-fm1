# Lucas Loops 0.4 validation

Firmware source: `5168e3fca7998233b5b2dc925e007a0ab97e5cec`. The production application and update package are byte-for-byte identical to the measured `e6f42b4` build; later changes restore legacy host font behavior and select the correct public loop pack in the build script.

The approved ivory, four-capsule layout is implemented in the actual 240×240 firmware LCD. Two pages replace the previous nested instruments/effects workflow. A dedicated four-loop mixer replaces the active synth/drum-machine path; the retained upstream source remains available for attribution and regression testing.

The public package includes eight loops rendered from SLOOP instruments and two distinct CC0 rhythm arrangements. Personal rhythms remain local. All ten are 72 BPM / D major / one bar.

## Measured results

The strict native emulator executes the final compiled package, with timed LCD SPI and instruction costs. At 240 MHz, four audible loops used a maximum 833 µs per audio half-buffer against a 5804 µs deadline, with zero late callbacks or voice shedding. At the 100 MHz stress setting, maximum time was 2007 µs; one late callback was observed during the run. Both runs retained all four enabled lanes and generated audio. These emulator results are not physical hardware measurements.

Application: 480148 bytes. Data/BSS: 46648 bytes. Pool: 89112 bytes. Low RAM: 4352 bytes. All are within their configured budgets.

SAVE/reboot restored the changed pad and all four enabled lanes, with transport stopped. Chooser cancellation left the loaded sound intact. Host integration tests cover draft/commit, late bar-boundary loading, fixed knob roles, silence with levels down, migration, and exclusion of keyboard/drum voices. ASan/UBSan, collection packing and web tests passed locally.

Evidence: `evidence/0.4/`; firmware-rendered screens: `screenshots/0.4/`. The browser runs the same compiled firmware using fm1-emu WebAssembly, AudioWorklet and sparse IndexedDB flash saves. Hardware remains untested.

Browser verification: Start listening unlocked controls after boot; Play, layer selection/toggling, PRESETS, Load loop and knob arrow adjustment were exercised. Save reported successful browser storage. Reload restored round bass and all four enabled layers. Browser console showed no errors or warnings.

## Retained upstream checks

The completed full run at e6f42b4 preserved all **182 audio golden renders**, with zero health failures, routing failures or crashes. It was **not green**: copied legacy font descriptors lost uppercase folding, and the old static timing checker expected removed drum/slicer functions and compared the new inlined mixer against the old audio interrupt budget.

The font behavior is fixed in ab3a3e8. The font test, 40000-frame stress test and 15000-frame ASan/UBSan stress test all pass locally after that fix. A rebuilt production application and update package were verified byte-for-byte identical, so the measured audio and browser evidence remains applicable. Preloading the public collection also reproduces the exact tested play-ready package.

Static checks remain failing: sample cost 662 versus 126, legacy grain 2387 versus 1734, new inlined audio interrupt 3835 versus the old 174, and absent slicer_track/drums_mix. These are not claims that the whole upstream suite passes. No timing baseline or audio golden was relaxed. The dedicated strict emulator measurements above test the actual loop workload.

CI: https://github.com/lucasm3110/sloop-fm1/actions/runs/43607177838 (completed full regression evidence); later build-only changes are covered by identity comparison and targeted font/stress checks. The follow-up full CI run may still be running when this delivery is opened.
